	var airApplicationArguments = "f7bee07a7e79c8efdb961c4d30d20e10c66442110de03d6141";

	createCookie("airApplicationArguments", airApplicationArguments, 10);

